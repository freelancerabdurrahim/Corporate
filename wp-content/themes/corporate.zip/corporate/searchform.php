<div class="searchform">
	<form method="get" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
		<p>
			<input type="text" name="s" id="searchbox" />	
			<input type="submit" src="<?php bloginfo('template_directory'); ?>/images/searchbutton.jpg" id="searchbutton" value=""/>		
		</p>
	</form>
</div>