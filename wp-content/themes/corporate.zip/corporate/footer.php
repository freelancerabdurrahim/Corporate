		</div> <!-- contentwrapper -->
		<div id="footer" class="span-24">
			<div class="span-24"><?php wp_footer(); ?></div>
			<div class="span-22 prepend-1 last">Powered by <a href="http://wordpress.org">WordPress</a> | Theme design by <a href="http://www.oripearl.com/">Ori Pearl</a></div>
		</div>
	</div> <!-- container -->
</body>
</html>